package Exercise1;

public abstract class Arthematic {
	
	abstract int calculate(int num1,int num2);
	abstract int read();
	abstract void display(int result);
}
