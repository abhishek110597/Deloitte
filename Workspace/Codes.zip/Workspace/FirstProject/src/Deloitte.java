
public class Deloitte {
	public void displayDeloitte() {
		System.out.println("Welcome to Deloitte, Bengaluru");	
	}
	
}
