
public class Exit {
public void end() {
	System.out.println("End of project");
}
}
