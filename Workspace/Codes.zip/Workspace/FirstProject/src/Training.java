
public class Training {
public void display() {
	System.out.println("Welcome to training");	
}
}
