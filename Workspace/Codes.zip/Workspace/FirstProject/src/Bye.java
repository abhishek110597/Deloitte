
public class Bye {
public void sayThanks() {
	System.out.println("Bye, sayThanks is called");
}
}
